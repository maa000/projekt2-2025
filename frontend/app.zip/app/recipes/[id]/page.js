// app/recipes/[id]/page.js
import Image from "next/image";

async function getRecipe(id) {
    const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/recipes/${id}`, {
        next: { revalidate: 60 }, // 60 másodpercenként újrafetch-el
    });

    if (!res.ok) {
        throw new Error("Nem sikerült betölteni a receptet");
    }

    const data = await res.json();
    return data.data;
}

export default async function RecipeDetailPage({ params }) {
    const recipe = await getRecipe(params.id);

    return (
        <section className="px-8 py-10 bg-violet-100 min-h-screen">
            <div className="max-w-3xl mx-auto bg-white rounded-lg shadow-md p-6">
                <h1 className="text-4xl font-bold mb-4">{recipe.title}</h1>
                <Image
                    src={recipe.image_url}
                    alt={recipe.title}
                    width={800}
                    height={500}
                    className="w-full h-auto rounded-lg mb-4"
                />
                <p className="text-lg mb-4"><strong>Értékelés:</strong> {recipe.rating} / 5</p>
                <div className="prose">
                    <h2>Elkészítés</h2>
                    <p>{recipe.description}</p>
                </div>
            </div>
        </section>
    );
}